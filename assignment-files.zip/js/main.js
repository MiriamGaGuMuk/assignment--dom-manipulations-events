// GO!

// TASK 1 -- Show/Hide Nav
//   HINT: you may want to use the following methods:
//   domEl.classList.contains(), domEl.classList.add(),

// TASK 2 -- Select an Icon


// TASK 3 -- Increase total number


// TASK 4 (Adventure Mode)-- Move Item List to List


// TASK 5 (Adventure Mode) -- Change Text Background Color From Palette
